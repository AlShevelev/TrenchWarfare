<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Game objects" tilewidth="64" tileheight="64" tilecount="54" columns="9">
 <image source="../images/tiles/game_object_atlas.png" width="576" height="384"/>
</tileset>
